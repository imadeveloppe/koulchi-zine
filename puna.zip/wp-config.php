<?php
/**
 * La configuration de base de votre installation WordPress.
 *
 * Ce fichier contient les réglages de configuration suivants : réglages MySQL,
 * préfixe de table, clés secrètes, langue utilisée, et ABSPATH.
 * Vous pouvez en savoir plus à leur sujet en allant sur
 * {@link http://codex.wordpress.org/fr:Modifier_wp-config.php Modifier
 * wp-config.php}. C’est votre hébergeur qui doit vous donner vos
 * codes MySQL.
 *
 * Ce fichier est utilisé par le script de création de wp-config.php pendant
 * le processus d’installation. Vous n’avez pas à utiliser le site web, vous
 * pouvez simplement renommer ce fichier en "wp-config.php" et remplir les
 * valeurs.
 *
 * @package WordPress
 */

// ** Réglages MySQL - Votre hébergeur doit vous fournir ces informations. ** //
/** Nom de la base de données de WordPress. */
define('DB_NAME', 'sh1betabox_rg');

/** Utilisateur de la base de données MySQL. */
define('DB_USER', 'sh1betabox_rg');

/** Mot de passe de la base de données MySQL. */
define('DB_PASSWORD', 'Ryv54!s9');

/** Adresse de l’hébergement MySQL. */
define('DB_HOST', 'localhost');

/** Jeu de caractères à utiliser par la base de données lors de la création des tables. */
define('DB_CHARSET', 'utf8mb4');

/** Type de collation de la base de données.
  * N’y touchez que si vous savez ce que vous faites.
  */
define('DB_COLLATE', '');

/**#@+
 * Clés uniques d’authentification et salage.
 *
 * Remplacez les valeurs par défaut par des phrases uniques !
 * Vous pouvez générer des phrases aléatoires en utilisant
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ le service de clefs secrètes de WordPress.org}.
 * Vous pouvez modifier ces phrases à n’importe quel moment, afin d’invalider tous les cookies existants.
 * Cela forcera également tous les utilisateurs à se reconnecter.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Fmb2sqpL37k~3Oh7Ld@XFgF;Bg+>-HzFR`0.yY`l&J5~h?&-e[%W-$*$ &KCk/<d');
define('SECURE_AUTH_KEY',  '{,gBQhbGz27Bi~EX+>pTRVU6$%rH%Do#AQtucKw{#0&^64uU*DNyR>>y)zXrwp9A');
define('LOGGED_IN_KEY',    '?Ko7%Acg!- K=BMWHBPO(#YI/U+rGD8TTw tfwvtEZp6g0(Hzs/-^hrDWRZ]0#3y');
define('NONCE_KEY',        'mbYL}RA<*J&N8*z{3Ud~/I2mHiJepEj8;^DrT~:NvL{%[4NHD2aweO*hzXp]8d>Y');
define('AUTH_SALT',        'f-aGqNt&7Yk{PNQyn:.*~BCTF+hT%edT x8VkWIl0!%P?^~ lKG_*i@wOJ%2MhLa');
define('SECURE_AUTH_SALT', 'zunjS53s2zpe9:a<PdWD9~{17PIQZox8Jl2},k)K; yE<3c(`nWs>J%cxLU2/<*]');
define('LOGGED_IN_SALT',   'weNOwc+4MI.mvunRG+D9p STu/*ct[k-/EX1YTg)9@vRRFGtg0c>_Y!E.O&_r_+F');
define('NONCE_SALT',       'M?w-;c(]gKDy2I<&-QdL_I0}#8+sv[xt6 !OAXHo|gfi&6K76MId.!Yf3S,B@nIG');
/**#@-*/

/**
 * Préfixe de base de données pour les tables de WordPress.
 *
 * Vous pouvez installer plusieurs WordPress sur une seule base de données
 * si vous leur donnez chacune un préfixe unique.
 * N’utilisez que des chiffres, des lettres non-accentuées, et des caractères soulignés !
 */
$table_prefix  = 'wp_';

/**
 * Pour les développeurs : le mode déboguage de WordPress.
 *
 * En passant la valeur suivante à "true", vous activez l’affichage des
 * notifications d’erreurs pendant vos essais.
 * Il est fortemment recommandé que les développeurs d’extensions et
 * de thèmes se servent de WP_DEBUG dans leur environnement de
 * développement.
 *
 * Pour plus d’information sur les autres constantes qui peuvent être utilisées
 * pour le déboguage, rendez-vous sur le Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* C’est tout, ne touchez pas à ce qui suit ! */

/** Chemin absolu vers le dossier de WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Réglage des variables de WordPress et de ses fichiers inclus. */
require_once(ABSPATH . 'wp-settings.php');
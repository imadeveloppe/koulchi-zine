<?php
	/**
	 *  booking-overview.php
	 *  Booking Overview Page of Puna theme
	 *  Template Name: Booking Overview
	 */

	get_header();
?>
	<div class="page-main-container main-bg-color">
		<div class="inner-box container">
			<?php
				if ( have_posts() )
				{
					while ( have_posts() )
					{
						the_post();
						the_content();
					}
				}
			?>
			<div id="overview-calendar"></div>
		</div>
	</div>
<?php
	get_footer();
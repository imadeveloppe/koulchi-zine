<?php
	/**
	 *    no-sidebar-no-breadcrumb.php
	 *    No Sidebar template of Puna
	 *  Template Name: No Sidebar & No Breadcrumb Page
	 */

	get_header();

	if ( have_posts() )
	{
		while ( have_posts() )
		{
			the_post();
			the_content();
		}
	}
	get_footer();